package com.example.augmented_reality

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
